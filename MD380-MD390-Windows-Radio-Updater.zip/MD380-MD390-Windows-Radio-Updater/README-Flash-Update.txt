************************************************************
   Here is the short version on how to upgrade your radio 
           to the latest Experimental Firmware
************************************************************

Go to http://www.foxhollow.ca/DMR/?menu=experimental
Grab the latest firmware "For Your Radio"

Unzip the files... Most likely you want the file ending
with NoGPS.bin

Turn on the radio while holding 2 of the side buttons,
the PPT button and the small button above it.

The LED on top of the radio should be blinking RED & GREEN
Do not proceed unless you see the RED/GREEN blink pattern

Run the "MD380-MD390 Updater.exe"

1: Select the firmware file
2: Click on the 2nd button to start the flash


************************************************************
The original update.exe was hacked from Chinese into English 
& Modified by VE3PZR. 

If you find any left over Chinese in the program, note the 
circumstances and post a message on the MD380 yahoo group
************************************************************
      https://groups.yahoo.com/neo/groups/TYT-TYTERA
************************************************************
          Last updated by VE3PZR:  Oct 10, 2016
************************************************************