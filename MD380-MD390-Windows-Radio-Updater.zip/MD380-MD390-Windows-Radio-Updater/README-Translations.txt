*****************************************************************
  How to derive translations for the MD380-MD390 Flash program
*****************************************************************

It is possible to replace the text in the Flash Updater with
words from another language.

Program space for text is limited. We have to work within 
some guidelines.

*****************************************************************
***             Here are the texts and descriptions:          ***
*****************************************************************
The main box describes the nature of this program.
Flexible: We can have a long sentence here (maximum 60 chars)
English  "Update your radio with Downloaded Firmware from the Internet"
French   "Update votre radio avec Firmware de l'Internet"
Italiano "Aggiorna la tua radio con il firmware scaricato da Internet"
Espanol  "Actualiza tu radio con Firmware descargado de Internet"
Deutsch  "Aktualisiert Ihr Radio mit neuer Firmware aus dem Internet"

*****************************************************************
Button 1: This allows the user to select the firmware file to load
Flexible:  maximum 30 letters
English  "1: Select the New Firmware"
French   "1: Choisir un nouveau firmware"
Italiano "1: Selezionare il nuovo firmware"
Espanol  "1: Seleccione el nuevo firmware"
Deutsch  "1: Neue Firmware ausw�hlen"

*****************************************************************
Button 2: This starts the flash process to your radio
Flexible: maximum 30 letters
English  "2: Update the MD380 ~ MD390"
French   "2: Update le MD380 ~ MD390"
Italiano "2: Aggiornare il MD380 ~ MD390"
Espanol  "2: Actualizar el MD380 ~ MD390"
Deutsch  "2: Update f�r MD380 ~ MD390"

*****************************************************************
***                    POPUP Messages:                        ***
*****************************************************************
When you have successfully completed the flashing of your radio,
a success message is displayed.
Static: maximum 19 letters
English  "Flashing Completed"
French   "Termine flash"
Italiano "Flashing Completato"
Espanol  "Finalizado"
Deutsch  "Flashen beendet!!"

*****************************************************************
When the Flash fails to load, a popup occurs.
You can test this message by turning off the radio after the
flash process has started.
Static: maximum 15 letters
English  "Flash Error!!"
French   "Erreur de Flash"
Italiano "Errore Flash !!"
Espanol  "Error de Flash"
Deutsch  "Flash Fehler!!"

*****************************************************************
When you have a problem with your USB and the Radio that stops
the flash process from starting, a message is displayed.
Suggestion solutions are:  (most are too long to fit)
   "USB Error",
   "Is USB Connected?", 
   "Is Radio powered on?"
Static: maximum 15 letters
English  "Is Radio ON?"
French   "Est Radio?"
Italiano "E la radio ON?"
Espanol  "Conectar radio"
Deutsch  "Ist Radio ON?"

*****************************************************************
When you have tried to start the flash but you have not yet
chosen the firmware file:
Static: maximum 19 letters
English  "1:Select firmware!"
French   "1:Choisir firmware!
Italiano "1: Selezionare..."
Spanish  "1: Seleccione..."
Deutsch  "1: Zuerst Firmware!"

*****************************************************************
***                      TRANSLATIONS                         ***
*****************************************************************
English:  Mark Bramwell, VE3PZR
French:   Mark Bramwell, VE3PZR
Italiano: Moreno Gentile & Fabio Alunni Breccolenti, iw0qpp
Espanol:  Mario Prat, EB3BKW
Deutsch:  Peter Amsler, HB9DWW


*****************************************************************
            Last Updated by VE3PZR: Dec 18, 2016
       http://www.foxhollow.ca/DMR/?menu=experimental
*****************************************************************

